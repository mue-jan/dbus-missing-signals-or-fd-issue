wget https://github.com/mue-jan/dbus-missing-signals-or-fd-issue/raw/master/files.zip
unzip files.zip
sudo cp *.conf /etc/dbus-1/system.d/
make
./mbsp_signal_receiver
./mbsp_signal_sender

Compare behavior to source-code - expecting the reception of signals
