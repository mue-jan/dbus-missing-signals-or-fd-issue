wget http://...files.zip
unzip files.zip
move *.conf files to /etc/dbus-1/system.d/
make
start sender and receiver applications
compare behavior to source-code

